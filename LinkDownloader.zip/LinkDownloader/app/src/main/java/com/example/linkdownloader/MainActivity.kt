package com.example.linkdownloader

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.URLUtil
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

data class Item(val id: Long, val name: String, val status: Int, val done: Long, val total: Long)

class MainActivity : ComponentActivity() {
    private var incoming by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleShare(intent)
        setContent { MaterialTheme { App(incoming) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    private fun handleShare(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return
        incoming = Regex("""https?://\S+""").find(text)?.value ?: text.trim()
    }
}

private fun listDownloads(dm: DownloadManager): List<Item> =
    dm.query(DownloadManager.Query()).use { c ->
        buildList {
            while (c.moveToNext()) {
                add(
                    Item(
                        id = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)),
                        name = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)) ?: "arquivo",
                        status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)),
                        done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)),
                        total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)),
                    )
                )
            }
        }.reversed()
    }

private fun statusText(s: Int) = when (s) {
    DownloadManager.STATUS_PENDING -> "Na fila"
    DownloadManager.STATUS_RUNNING -> "Baixando"
    DownloadManager.STATUS_PAUSED -> "Aguardando rede"
    DownloadManager.STATUS_SUCCESSFUL -> "Concluído"
    DownloadManager.STATUS_FAILED -> "Falhou"
    else -> ""
}

@Composable
fun App(sharedLink: String = "") {
    val ctx = LocalContext.current
    val dm = remember { ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager }
    var url by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var items by remember { mutableStateOf(listOf<Item>()) }

    LaunchedEffect(sharedLink) {
        if (sharedLink.isNotEmpty()) url = sharedLink
    }

    LaunchedEffect(Unit) {
        while (true) {
            items = listDownloads(dm)
            delay(500)
        }
    }

    fun start() {
        val u = url.trim()
        val uri = runCatching { Uri.parse(u) }.getOrNull()
        if (uri == null || uri.scheme != "https") {
            error = "Cole um link https:// válido para um arquivo."
            return
        }
        val name = URLUtil.guessFileName(u, null, null)
        val req = DownloadManager.Request(uri)
            .setTitle(name)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
        dm.enqueue(req)
        url = ""
        error = null
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            label = { Text("Link do arquivo (https)") },
            isError = error != null,
            supportingText = { error?.let { Text(it) } },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        Button(onClick = { start() }, modifier = Modifier.fillMaxWidth()) { Text("Baixar") }
        Spacer(Modifier.height(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(items, key = { it.id }) { item ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(item.name, maxLines = 1)
                        Text(statusText(item.status), style = MaterialTheme.typography.bodySmall)
                        if (item.status != DownloadManager.STATUS_SUCCESSFUL && item.total > 0) {
                            LinearProgressIndicator(
                                progress = { item.done.toFloat() / item.total },
                                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                            )
                        }
                    }
                    TextButton(onClick = { dm.remove(item.id) }) {
                        Text(if (item.status == DownloadManager.STATUS_SUCCESSFUL) "Remover" else "Cancelar")
                    }
                }
            }
        }
    }
}
