package com.example.linkdownloader

import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.URLUtil
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.naman14.androidlame.AndroidLame
import com.naman14.androidlame.LameBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class Fmt(val label: String, val height: Int = 0) {
    ORIGINAL("Original (sem converter)"),
    MP3_128("MP3 clássico (128k)"),
    MP3_320("MP3 alta qualidade (320k)"),
    WAV("WAV (sem perda)"),
    V1080("Vídeo MP4 1080p", 1080),
    V720("Vídeo MP4 720p", 720),
    V480("Vídeo MP4 480p", 480),
    V360("Vídeo MP4 360p", 360),
}

data class Item(val id: Long, val name: String, val status: Int, val done: Long, val total: Long, val local: String?)

class MainActivity : ComponentActivity() {
    private var incoming by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleShare(intent)
        setContent { MaterialTheme { App(incoming) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    private fun handleShare(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return
        incoming = Regex("""https?://\S+""").find(text)?.value ?: text.trim()
    }
}

// ---------- Downloads ----------

private fun listDownloads(dm: DownloadManager): List<Item> =
    dm.query(DownloadManager.Query()).use { c ->
        buildList {
            while (c.moveToNext()) {
                add(
                    Item(
                        id = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)),
                        name = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)) ?: "arquivo",
                        status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)),
                        done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)),
                        total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)),
                        local = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI)),
                    )
                )
            }
        }.reversed()
    }

private fun statusText(s: Int) = when (s) {
    DownloadManager.STATUS_PENDING -> "Na fila"
    DownloadManager.STATUS_RUNNING -> "Baixando"
    DownloadManager.STATUS_PAUSED -> "Aguardando rede"
    DownloadManager.STATUS_SUCCESSFUL -> "Concluído"
    DownloadManager.STATUS_FAILED -> "Falhou"
    else -> ""
}

// ---------- Conversão ----------

private fun decode(path: String, sink: (ByteArray, Int) -> Unit, onFormat: (Int, Int) -> Unit) {
    val ex = MediaExtractor()
    ex.setDataSource(path)
    val idx = (0 until ex.trackCount).firstOrNull {
        ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
    } ?: throw IllegalStateException("O arquivo não tem áudio")
    ex.selectTrack(idx)
    val fmt = ex.getTrackFormat(idx)
    onFormat(fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE), fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
    val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
    codec.configure(fmt, null, null, 0)
    codec.start()
    val info = MediaCodec.BufferInfo()
    var inDone = false
    var outDone = false
    while (!outDone) {
        if (!inDone) {
            val i = codec.dequeueInputBuffer(10_000)
            if (i >= 0) {
                val n = ex.readSampleData(codec.getInputBuffer(i)!!, 0)
                if (n < 0) {
                    codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    inDone = true
                } else {
                    codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                    ex.advance()
                }
            }
        }
        val o = codec.dequeueOutputBuffer(info, 10_000)
        if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
            val f = codec.outputFormat
            onFormat(f.getInteger(MediaFormat.KEY_SAMPLE_RATE), f.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
        } else if (o >= 0) {
            if (info.size > 0) {
                val b = codec.getOutputBuffer(o)!!
                b.position(info.offset)
                val arr = ByteArray(info.size)
                b.get(arr)
                sink(arr, arr.size)
            }
            codec.releaseOutputBuffer(o, false)
            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
        }
    }
    codec.stop(); codec.release(); ex.release()
}

private fun toWav(src: String, out: File) {
    var rate = 44100; var ch = 2; var total = 0L
    RandomAccessFile(out, "rw").use { raf ->
        raf.write(ByteArray(44))
        decode(src, { b, n -> raf.write(b, 0, n); total += n }, { r, c -> rate = r; ch = c })
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()).putInt((36 + total).toInt()).put("WAVE".toByteArray())
            .put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(ch.toShort())
            .putInt(rate).putInt(rate * ch * 2).putShort((ch * 2).toShort()).putShort(16)
            .put("data".toByteArray()).putInt(total.toInt())
        raf.seek(0); raf.write(h.array())
    }
}

private fun toMp3(src: String, out: File, kbps: Int) {
    var lame: AndroidLame? = null
    var rate = 44100; var ch = 2
    out.outputStream().buffered().use { os ->
        decode(src, { buf, n ->
            if (ch > 2) throw IllegalStateException("Áudio com mais de 2 canais não suportado")
            if (lame == null) {
                lame = LameBuilder().setInSampleRate(rate).setOutChannels(2)
                    .setOutBitrate(kbps).setOutSampleRate(rate).build()
            }
            val sh = ShortArray(n / 2)
            ByteBuffer.wrap(buf, 0, n).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(sh)
            val inter = if (ch == 1) ShortArray(sh.size * 2) { sh[it / 2] } else sh
            val frames = inter.size / 2
            val mp3 = ByteArray(7200 + (frames * 1.25).toInt())
            val w = lame!!.encodeBufferInterLeaved(inter, frames, mp3)
            if (w > 0) os.write(mp3, 0, w)
        }, { r, c -> rate = r; ch = c })
        lame?.let {
            val b = ByteArray(7200)
            val w = it.flush(b)
            if (w > 0) os.write(b, 0, w)
            it.close()
        }
    }
}

private suspend fun toVideo(ctx: Context, src: String, out: File, height: Int) =
    withContext(Dispatchers.Main) {
        val srcH = MediaMetadataRetriever().run {
            setDataSource(src)
            val h = extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
            release(); h
        }
        val effects = if (srcH != null && srcH <= height) Effects(emptyList(), emptyList())
        else Effects(emptyList(), listOf(Presentation.createForHeight(height)))
        val item = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(File(src)))).setEffects(effects).build()
        suspendCancellableCoroutine<Unit> { cont ->
            val t = Transformer.Builder(ctx)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) = cont.resume(Unit)
                    override fun onError(composition: Composition, exportResult: ExportResult, e: ExportException) =
                        cont.resumeWithException(e)
                }).build()
            t.start(item, out.absolutePath)
            cont.invokeOnCancellation { t.cancel() }
        }
    }

private fun publish(ctx: Context, file: File, name: String, mime: String) {
    val cv = ContentValues().apply {
        put(MediaStore.Downloads.DISPLAY_NAME, name)
        put(MediaStore.Downloads.MIME_TYPE, mime)
        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
    }
    val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
    ctx.contentResolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
}

private suspend fun convert(ctx: Context, src: String, fmt: Fmt, base: String): String {
    val tmp = File(ctx.cacheDir, "conv_${System.nanoTime()}")
    val (name, mime) = when (fmt) {
        Fmt.MP3_128, Fmt.MP3_320 -> "$base.mp3" to "audio/mpeg"
        Fmt.WAV -> "$base.wav" to "audio/x-wav"
        else -> "${base}_${fmt.height}p.mp4" to "video/mp4"
    }
    try {
        when (fmt) {
            Fmt.MP3_128 -> withContext(Dispatchers.IO) { toMp3(src, tmp, 128) }
            Fmt.MP3_320 -> withContext(Dispatchers.IO) { toMp3(src, tmp, 320) }
            Fmt.WAV -> withContext(Dispatchers.IO) { toWav(src, tmp) }
            else -> toVideo(ctx, src, tmp, fmt.height)
        }
        withContext(Dispatchers.IO) { publish(ctx, tmp, name, mime) }
    } finally {
        tmp.delete()
    }
    return name
}

// ---------- UI ----------

@Composable
fun App(sharedLink: String = "") {
    val ctx = LocalContext.current
    val dm = remember { ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager }
    val prefs = remember { ctx.getSharedPreferences("pending", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var items by remember { mutableStateOf(listOf<Item>()) }
    var fmt by remember { mutableStateOf(Fmt.ORIGINAL) }
    var menu by remember { mutableStateOf(false) }
    val conv = remember { mutableStateMapOf<Long, String>() }

    LaunchedEffect(sharedLink) {
        if (sharedLink.isNotEmpty()) url = sharedLink
    }

    LaunchedEffect(Unit) {
        while (true) {
            val list = listDownloads(dm)
            items = list
            val pend = prefs.getStringSet("p", emptySet())!!.toSet()
            for (entry in pend) {
                val id = entry.substringBefore(":").toLong()
                val f = Fmt.valueOf(entry.substringAfter(":"))
                val it = list.find { x -> x.id == id }
                if (it == null || it.status == DownloadManager.STATUS_FAILED ||
                    it.status == DownloadManager.STATUS_SUCCESSFUL
                ) {
                    prefs.edit().putStringSet("p", prefs.getStringSet("p", emptySet())!!.toSet() - entry).apply()
                }
                if (it != null && it.status == DownloadManager.STATUS_SUCCESSFUL && id !in conv) {
                    conv[id] = "Convertendo…"
                    val path = Uri.parse(it.local ?: "").path
                    val base = it.name.substringBeforeLast('.')
                    scope.launch {
                        conv[id] = try {
                            "Salvo em Downloads: " + convert(ctx, path!!, f, base)
                        } catch (e: Throwable) {
                            "Erro na conversão: ${e.message ?: e.javaClass.simpleName}"
                        }
                    }
                }
            }
            delay(500)
        }
    }

    fun start() {
        val u = url.trim()
        val uri = runCatching { Uri.parse(u) }.getOrNull()
        if (uri == null || uri.scheme != "https") {
            error = "Cole um link https:// válido para um arquivo."
            return
        }
        val name = URLUtil.guessFileName(u, null, null)
        val req = DownloadManager.Request(uri)
            .setTitle(name)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        if (fmt == Fmt.ORIGINAL) req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
        else req.setDestinationInExternalFilesDir(ctx, Environment.DIRECTORY_DOWNLOADS, name)
        val id = dm.enqueue(req)
        if (fmt != Fmt.ORIGINAL) {
            prefs.edit().putStringSet("p", prefs.getStringSet("p", emptySet())!!.toSet() + "$id:${fmt.name}").apply()
        }
        url = ""
        error = null
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            label = { Text("Link do arquivo (https)") },
            isError = error != null,
            supportingText = { error?.let { Text(it) } },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        Box {
            OutlinedButton(onClick = { menu = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Formato: ${fmt.label}  ▾")
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                Fmt.values().forEach { f ->
                    DropdownMenuItem(text = { Text(f.label) }, onClick = { fmt = f; menu = false })
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = { start() }, modifier = Modifier.fillMaxWidth()) { Text("Baixar") }
        Spacer(Modifier.height(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(items, key = { it.id }) { item ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(item.name, maxLines = 1)
                        Text(conv[item.id] ?: statusText(item.status), style = MaterialTheme.typography.bodySmall)
                        if (item.status != DownloadManager.STATUS_SUCCESSFUL && item.total > 0) {
                            LinearProgressIndicator(
                                progress = { item.done.toFloat() / item.total },
                                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                            )
                        }
                    }
                    TextButton(onClick = { dm.remove(item.id) }) {
                        Text(if (item.status == DownloadManager.STATUS_SUCCESSFUL) "Remover" else "Cancelar")
                    }
                }
            }
        }
    }
}
